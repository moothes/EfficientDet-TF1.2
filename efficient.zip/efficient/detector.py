from model import efficientdet
from utils import preprocess_image, postprocess_boxes, nms
from utils.draw_boxes import draw_boxes
from utils.anchors import anchors_for_shape
from layers import bbox_transform_inv
import numpy as np
import os
import cv2
import time

os.environ['CUDA_VISIBLE_DEVICES'] = ''

class Mask_Detector():
    def __init__(self, config):
        self.config = config

        self.classes = {1: 'facemask', 0: 'face'}
        #log.info("Init model with {}".format(self.config))
        
        model_path = './checkpoints/2020-04-10/facemask_28_0.2152.h5'
        #image_size = 512
        
        num_classes = 2
        #score_threshold = 0.3
        self.model = efficientdet(phi=0, num_classes=2, score_threshold=0.3)
        self.model.load_weights(model_path, by_name=True)
    
    def detect_mask(self, frame):
        image = frame[:, :, ::-1]
        #boxes, classex, probs = self.YOLO.detect_image1(image)
        
        h, w = image.shape[:2]

        image, scale = preprocess_image(image, image_size=512)
        cls, res = self.model.predict_on_batch([np.expand_dims(image, axis=0)])
        
        anchor = anchors_for_shape(image.shape[:2])
        boxes = bbox_transform_inv(anchor, res)
        labels = np.argmax(cls, axis=-1)
        scores = np.max(cls, axis=-1)
        
        boxes, scores, labels = np.squeeze(boxes), np.squeeze(scores), np.squeeze(labels)
        boxes = postprocess_boxes(boxes=boxes, scale=scale, height=h, width=w)

        indices = np.where(scores > 0.3)[0]

        boxes = boxes[indices]
        labels = labels[indices]
        scores = scores[indices]
        
        boxes, kps = nms(boxes)
        labels = labels[kps]
        #sprint(len(scores))
        scores = scores[kps]
        return boxes, labels, scores
        
detector = Mask_Detector(None)

path = '/new_home/zcxiong/GRG_Datasets/GRG_Obj_Detection/facemask/facemask_jpg_20200312/'
img_list = os.listdir(path)
colors = [np.random.randint(0, 256, 3).tolist() for _ in range(2)]
classes = {1: 'facemask', 0: 'face'}
for img_name in img_list:
    image_path = path + img_name
    image = cv2.imread(image_path)
    st = time.time()
    boxes, labels, scores = detector.detect_mask(image)
    print(time.time() - st)
    print(colors)
    draw_boxes(image, boxes, scores, labels, colors, classes)
    cv2.imwrite('/home/zhjun13/eff/result/{}'.format(img_name), image)
    print('Image {} is saved!.'.format(img_name))



