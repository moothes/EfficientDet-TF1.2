import cv2
import json
import numpy as np
import os
import time
import glob

from model import efficientdet
from utils import preprocess_image, postprocess_boxes, nms
from utils.draw_boxes import draw_boxes
from utils.anchors import anchors_for_shape
from layers import bbox_transform_inv

def main(): 
    os.environ['CUDA_VISIBLE_DEVICES'] = ''

    phi = 0
    weighted_bifpn = False
    #model_path = 'efficientdet-d0.h5'
    #model_path = './checkpoints/2020-04-10/facemask_28_0.2152.h5'
    #model_path = './checkpoints/2020-06-15/hand_40_0.0193_0.0906.h5'
    model_path = './checkpoints/2020-06-15/hand_11_0.0425_0.0734.h5'
    #model_path = 'D:/facemask/eff/checkpoints/facemask_28_0.2152.h5'
    #image_sizes = (512, 640, 768, 896, 1024, 1280, 1408)
    image_size = 512 #image_sizes[phi]
    # coco classes
    classes = {1: 'hand', 0: 'face'} #{1: 'facemask', 0: 'face'}
    #classes = {value['id'] - 1: value['name'] for value in json.load(open('coco_90.json', 'r')).values()}
    num_classes = 2
    score_threshold = 0.3
    colors = [np.random.randint(0, 256, 3).tolist() for _ in range(num_classes)]
    model = efficientdet(phi=phi,
                            weighted_bifpn=weighted_bifpn,
                            num_classes=num_classes,
                            score_threshold=score_threshold)
    model.load_weights(model_path, by_name=True)

    path = '/home/zhjun13/eff/hand/img/' #'/new_home/zcxiong/GRG_Datasets/GRG_Obj_Detection/facemask/facemask_jpg_20200312/'
    img_list = os.listdir(path)
    for img_name in img_list:
        image_path = path + img_name
        #print(len(glob.glob('/media/data2/zhouhj/datasets/voc/images/*.jpg')))
        #for image_path in glob.glob('/media/data2/zhouhj/datasets/voc/images/*.jpg'):
        image = cv2.imread(image_path)
        #image_tag = image_path.split('/')[-1]
        src_image = image.copy()
        # BGR -> RGB
        image = image[:, :, ::-1]
        h, w = image.shape[:2]

        image, scale = preprocess_image(image, image_size=image_size)
        # run network
        start = time.time()
        #boxes, scores, labels = model.predict_on_batch([np.expand_dims(image, axis=0)])
        cls, res = model.predict_on_batch([np.expand_dims(image, axis=0)])
        anchor = anchors_for_shape(image.shape[:2])
        
        boxes = bbox_transform_inv(anchor, res)
        labels = np.argmax(cls, axis=-1)
        scores = np.max(cls, axis=-1)
        
        boxes, scores, labels = np.squeeze(boxes), np.squeeze(scores), np.squeeze(labels)
        boxes = postprocess_boxes(boxes=boxes, scale=scale, height=h, width=w)

        # select indices which have a score above the threshold
        indices = np.where(scores > score_threshold)[0]

        # select those detections
        boxes = boxes[indices]
        labels = labels[indices]
        scores = scores[indices]
        
        #print(len(boxes), len(labels))
        boxes, kps = nms(boxes)
        labels = labels[kps]
        #sprint(len(scores))
        scores = scores[kps]
        print(time.time() - start)
        
        with open('./hand_pre.txt', 'a+') as f:
            video_name, frame_index = img_name.split('.')[0].split('+')
            line = [video_name, frame_index]
            for box, lbl in zip(boxes.astype(np.int64), labels):
                line.extend(box)
                line.append(lbl)
            print(line)
            line = [str(i) for i in line]
            line = ' '.join(line) + '\n'
            print(line)
            f.writelines(line)
        
        #print(len(boxes), len(labels))
        #print(boxes, labels)
        #draw_boxes(src_image, boxes, scores, labels, colors, classes)

        #cv2.namedWindow('image', cv2.WINDOW_NORMAL)
        #cv2.imshow('image', src_image)
        #print('/home/zhjun13/eff/result/hand/{}'.format(img_name))
        #cv2.imwrite('./result/{}'.format(img_name), src_image)
        #print('Image {} is saved!.'.format(img_name))
        #cv2.waitKey(0)


if __name__ == '__main__':
    main()
